// Loaded only when Captain Jack's sheet opens or the Ask field gets focus: the delivered rig
// (vendored unchanged) and its stylesheet. The rig bundle is a classic script that defines
// window.CaptainJack; it is emitted as an asset and loaded with a <script>, because a bare
// side-effect import is dropped under the package's "sideEffects": false.
import css from '../vendor/captain-jack/avatar.css?raw';
import rigUrl from '../vendor/captain-jack/captain-jack.js?url';

type CJ = { mount(el: HTMLElement, o: object): Rig };
const cj = () => (window as unknown as { CaptainJack?: CJ }).CaptainJack;
let loading: Promise<CJ> | null = null;
export const loadRig = (): Promise<CJ> => (loading ??= new Promise<CJ>((resolve, reject) => {
  if (cj()) return resolve(cj()!);
  const s = document.createElement('script');
  s.src = rigUrl;
  const fail = (why: string) => { loading = null; s.remove(); reject(new Error(why)); };
  s.onload = () => (cj() ? resolve(cj()!) : fail('CaptainJack missing'));
  s.onerror = () => fail('rig failed to load');
  document.head.append(s);
}));

export type JackState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'working' | 'success' | 'waiting' | 'attention';
export interface Rig {
  setState(s: JackState): void;
  setSpeechLevel(level: number | null): void;
  getState(): { state: JackState };
  destroy(): void;
}
export const rigCss = css;
export const mountRig = async (el: HTMLElement, state: JackState): Promise<Rig> =>
  (await loadRig()).mount(el, { state, autoplay: true, demoSpeech: false });
