// The product header's behaviour (ported from the prototype's frame.js): sticky and compact
// past scrollY 24, the ☰ drawer (a <details>, so it opens without JS), "/" to the Ask field,
// and the version pill refreshed from the latest GitHub release.
import { PRODUCTS, type Slug } from '../data/products';

export interface HeaderOpts { product: Slug; onAsk?: (question?: string) => void }

const typing = (el: Element | null): boolean => {
  let e: Element | null = el;
  while (e?.shadowRoot?.activeElement) e = e.shadowRoot.activeElement;
  return !!e && (/^(INPUT|TEXTAREA|SELECT)$/.test(e.tagName) || (e as HTMLElement).isContentEditable);
};

export function mountHeader(root: ShadowRoot, opts: HeaderOpts): void {
  const h = root.getElementById('h');
  if (h) {
    const stick = () => h.classList.toggle('stuck', scrollY > 24);
    addEventListener('scroll', stick, { passive: true });
    stick();
  }

  const menu = root.getElementById('menu') as HTMLDetailsElement | null;
  const summary = menu?.querySelector('summary');
  if (menu && summary) {
    const sync = () => summary.setAttribute('aria-expanded', String(menu.open));
    menu.addEventListener('toggle', sync);
    sync();
    root.getElementById('drawer')?.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => (menu.open = false)));
  }

  const ask = root.getElementById('askj') as HTMLButtonElement | null;
  if (ask) {
    ask.addEventListener('click', () => opts.onAsk?.());
    addEventListener('keydown', (e) => {
      if (e.key !== '/' || e.metaKey || e.ctrlKey || e.altKey || typing(document.activeElement)) return;
      e.preventDefault();
      ask.focus();
    });
  }

  void refreshVersion(root, opts.product);
}

/** The build bakes in a release; a newer one shows up without a rebuild. Silent on any failure. */
async function refreshVersion(root: ShadowRoot, slug: Slug): Promise<void> {
  const repo = PRODUCTS[slug].repo;
  const v = root.getElementById('ver') as HTMLAnchorElement | null;
  if (!repo || !v) return;
  try {
    const r = await fetch(`${repo.replace('https://github.com/', 'https://api.github.com/repos/')}/releases/latest`, { headers: { accept: 'application/vnd.github+json' } });
    if (!r.ok) return;
    const b = await r.json();
    if (typeof b?.tag_name !== 'string' || typeof b?.html_url !== 'string') return;
    v.textContent = b.tag_name;
    v.href = b.html_url;
    if (b.published_at) v.title = `Released ${new Date(b.published_at).toDateString()}`;
  } catch { /* the built value stays */ }
}
