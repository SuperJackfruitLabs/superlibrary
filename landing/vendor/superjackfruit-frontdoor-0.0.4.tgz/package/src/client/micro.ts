// Small motions shared by all six pages (ported from the prototype's micro.js). The page-level
// ones are vibekit's primitives (@superjackfruit/vibekit/dom); only the header logo's brand
// motion stays here (the street's windows and car live in street.ts). Every one is skipped
// under prefers-reduced-motion, and nothing is hidden before this script adds a class.
import { copyFeedback, magnetic, revealOnScroll, tilt, underlineDraw } from '@superjackfruit/vibekit/dom';
import vkDom from '@superjackfruit/vibekit/dom.css?raw';
import type { Slug } from '../data/products';

const STYLE_ID = 'sjl-vk-dom';

/** vibekit's dom.css on the page itself (reveal, underline, tilt and copy act on the page body), once. */
function injectDomCss(): void {
  if (document.getElementById(STYLE_ID)) return;
  const s = document.createElement('style');
  s.id = STYLE_ID;
  s.textContent = vkDom;
  document.head.append(s);
}

type Motion = { create(container: Element, slug: string): { play(): Promise<unknown> | void } };

async function logoOnHover(root: ShadowRoot, product: Slug): Promise<void> {
  const mark = root.getElementById('mark');
  const brand = root.getElementById('brand');
  if (!mark || !brand) return;
  try {
    await import('../vendor/logo-motion.js');
    const M = (globalThis as { SJLLogoMotion?: Motion }).SJLLogoMotion;
    if (!M) return;
    const box = document.createElement('div');
    box.style.cssText = 'width:100%;height:100%';
    const logo = M.create(box, product);
    mark.replaceChildren(box);
    let busy = false;
    brand.addEventListener('pointerenter', () => {
      if (busy) return;
      busy = true;
      Promise.resolve(logo.play()).finally(() => (busy = false));
    });
  } catch { /* the static mark stays */ }
}

export function mountMicro(opts: { product: Slug; header?: ShadowRoot | null }): void {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  injectDomCss();
  const { header } = opts;
  if (header) {
    void logoOnHover(header, opts.product);
    const s = document.createElement('style');
    s.textContent = vkDom.split('\n').filter((l) => l.startsWith('.vk-mag')).join('\n');
    header.append(s);
  }

  const hero = document.querySelector('h1')?.closest('section') ?? null;
  const targets = [...document.querySelectorAll('section h2, section h3, section p, section pre, section ul, section ol > li')]
    .filter((el) => !hero?.contains(el) && !el.closest('header, footer, nav, figure'));
  revealOnScroll(targets.filter((el) => !targets.some((t) => t !== el && t.contains(el))));

  const ctas = [...document.querySelectorAll<HTMLElement>('a, button')]
    .filter((el) => /^\s*get started\b/i.test(el.textContent ?? '') && (el.textContent ?? '').trim().length < 24 && !el.closest('header, footer'));
  const headCta = header?.querySelector<HTMLElement>('.cta');
  for (const el of headCta ? [...ctas, headCta] : ctas) magnetic(el);

  document.querySelectorAll<HTMLButtonElement>('button').forEach((b) => {
    if (/copy/i.test(`${b.textContent} ${b.getAttribute('aria-label') ?? ''} ${b.id}`)) copyFeedback(b);
  });

  underlineDraw(document);

  if (hero) {
    const text = document.querySelector('h1');
    const grid = [hero, ...hero.querySelectorAll('*')].find((el) => el.children.length >= 2 && [...el.children].some((c) => c.contains(text)) && getComputedStyle(el).display === 'grid');
    const demo = grid && [...grid.children].find((c) => !c.contains(text));
    if (demo instanceof HTMLElement) tilt(demo);
  }
}
