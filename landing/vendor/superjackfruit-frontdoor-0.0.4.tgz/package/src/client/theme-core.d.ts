export type Pref = 'system' | 'light' | 'dark';
export const PREF_KEY: string;
export function parsePref(v: unknown): Pref;
export function matchFragment(hash: string): Pref | null;
export interface ThemeEnv {
  site: { key: string; values: { light: string; dark: string } };
  read(key: string): string | null;
  write(key: string, value: string | null): void;
  systemLight(): boolean;
  paint(siteValue: string, effective: 'light' | 'dark'): void;
}
export interface Theme {
  get(): Pref;
  effective(): 'light' | 'dark';
  apply(): void;
  set(p: Pref): void;
  carry(): string;
}
export function createTheme(env: ThemeEnv): Theme;
