// Ported unchanged from the prototype's public/backdrop.js.
export function mountBackdrop(opts: { product: string; color: string; theme: () => 'light' | 'dark' }): { setTheme(t: 'light' | 'dark'): void };
